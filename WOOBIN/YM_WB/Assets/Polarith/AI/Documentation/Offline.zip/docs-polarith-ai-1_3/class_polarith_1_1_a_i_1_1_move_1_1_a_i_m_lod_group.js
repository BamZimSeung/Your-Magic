var class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group =
[
    [ "Center", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_adeca421507b3c3b3acc3eb5fd34dbd03.html#adeca421507b3c3b3acc3eb5fd34dbd03", null ],
    [ "UpdateFrequency", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_aa6c298786ca3622cfa67003ec210c281.html#aa6c298786ca3622cfa67003ec210c281", null ],
    [ "DeactivateOnLast", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_acfe52d3442e8a7b095c5271c4fc1edca.html#acfe52d3442e8a7b095c5271c4fc1edca", null ],
    [ "LodList", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_aac24dd77dc667f3ee4758d126e1c190c.html#aac24dd77dc667f3ee4758d126e1c190c", null ],
    [ "LodColor1", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_aecef200c928e2ef8666025c8eef2c2c1.html#aecef200c928e2ef8666025c8eef2c2c1", null ],
    [ "LodColor2", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_a5d490027d1bbc62b790135e2d0e66c72.html#a5d490027d1bbc62b790135e2d0e66c72", null ],
    [ "LodColor3", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_a8d0072b2a01c13bd273f05282b586d2b.html#a8d0072b2a01c13bd273f05282b586d2b", null ],
    [ "CenterTag", "class_polarith_1_1_a_i_1_1_move_1_1_a_i_m_lod_group_a25781cbea2386cbb83944fdd99d6b755.html#a25781cbea2386cbb83944fdd99d6b755", null ]
];