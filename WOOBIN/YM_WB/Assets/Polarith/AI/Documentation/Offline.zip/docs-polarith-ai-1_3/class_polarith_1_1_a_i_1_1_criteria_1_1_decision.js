var class_polarith_1_1_a_i_1_1_criteria_1_1_decision =
[
    [ "Values", "class_polarith_1_1_a_i_1_1_criteria_1_1_decision_a5d06617751cace1797909db7fa273128.html#a5d06617751cace1797909db7fa273128", null ],
    [ "Index", "class_polarith_1_1_a_i_1_1_criteria_1_1_decision_a075e1e3c9dd399cef584d7338cc37938.html#a075e1e3c9dd399cef584d7338cc37938", null ],
    [ "Structure", "class_polarith_1_1_a_i_1_1_criteria_1_1_decision_a2d354997fd6f3b3761b0fe929fb96213.html#a2d354997fd6f3b3761b0fe929fb96213", null ]
];